package com.example.layout_builder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
